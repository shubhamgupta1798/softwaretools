# taxidi_travelling_app
it's a travelling place descriptive web app
